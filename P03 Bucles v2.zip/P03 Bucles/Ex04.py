"""
Exercici 4

Fes un programa que demani l'ample i l'alt d'un programa i el dibuixi amb asteriscs.

Exemple de sortida:

Ample: 5
Alt: 3
*****
*   *
*****

"""