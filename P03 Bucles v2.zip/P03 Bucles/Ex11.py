"""
Fes un programa perquè digui si una lletra està al principi de l'abecedari o al final.

Es considera que el mig de l'abecedari és la lletra 'm'

"""