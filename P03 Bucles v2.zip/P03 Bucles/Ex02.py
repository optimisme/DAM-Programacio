"""
Exercici 11

Fes un programa que pregunti dos numeros "segments" i "repeticions"

El programa ha de dibuixar un patró de segments de la següent manera:

3 segments, 4 repeticions (dibuixa 3 asteriscs separats per 3 espais, 4 vegades):

***   ***   ***   ***

5 segments, 3 repeticions (dibuixa 5 asteriscs separats per 5 espais, 3 vegades):

*****     *****     *****

7 segments, 2 repeticions (dibuixa 7 asteriscs separats per 7 espais, 2 vegades):

*******       *******

"""