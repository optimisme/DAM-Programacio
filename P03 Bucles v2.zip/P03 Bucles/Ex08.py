"""
Exercici 8

Fes un programa que demani a l'usuari un número múltiple de 10.

Si el número no és múltiple de 10, el programa mostra el missatge 
"El número no és múltiple de 10" i torna a demanar el número.

Un cop tingui un número múltiple de 10, les següents dues columnes d'informació:

entrada          | missatge de sortida
1200             | 12 per 10 elevat a 2

Més exemples:

entrada          | missatge de sortida
2300000          | 23 per 10 elevat a 5

entrada          | missatge de sortida
24000            | 24 per 10 elevat a 3

entrada          | missatge de sortida
250              | 25 per 10 elevat a 1

"""