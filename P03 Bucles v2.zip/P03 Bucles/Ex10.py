"""
Fes un programa que escrigui l'abecedari de A a la Z amb un bucle 'for'.

Per fer-ho et caldrà la funció 'chr()' que et retorna el caràcter corresponent a un codi ASCII.

Totes les lletres de l'ordinador estàn codificades a partir de valors numèrics. Per exemple:

El caràcter 'a' en ASCII és el 97
El caràcter 'b' en ASCII és el 98
...
El caràcter 'z' en ASCII és el 122

Per tant, per escriure el caràcter 'A' has de fer print(chr(65)) i així fins la 'Z' en un bucle 'for'
"""