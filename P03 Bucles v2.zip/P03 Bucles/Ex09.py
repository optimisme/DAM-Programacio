"""
Exercici 9

Fes un programa que sumi tots els números primers entre 1 i 100

Un número és primer si:

- És més gran que 1

- No és divisible per cap número entre 2 i ell mateix

És a dir, hem de fer un bucle que comprovi entre 2 i el número X 
que tots els residus de la divisió siguin diferents de 0.

"""