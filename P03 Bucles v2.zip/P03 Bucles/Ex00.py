"""
Exercici 0

Escriu un generador de nombres parells entre 2 i un nombre n que es demana a l'usuari.

"""