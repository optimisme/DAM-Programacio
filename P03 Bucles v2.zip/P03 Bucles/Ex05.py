"""
Exercici 5

Fes un programa que demani dos números positius a l'usuari, anomenats 'base' i 'exponent'

Si els valors introduits no són positius, torna a demanar-los.

El programa ha de multiplicar la 'base' per ella mateixa 'exponent' vegades.

Al final s'ha de mostrar el resultat.

"""