"""
Exercici 10

Fes un programa que pregunti quants nombres es volen generar.

Si l'usuari introdueix un valor incorrecte, el torna a demanar.

Després ha de generar 'x' nombres aleatoris (on x és el valor que ha demanat l'usuari)

Per cada nombre generat, mostra els següents missatges segons correspongui:

- El nombre X és diferent de l'anterior Y

- En nombre X és igual a l'anterior

I així fins que hagi generat tots els nombres.

"""