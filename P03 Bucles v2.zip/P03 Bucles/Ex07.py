"""
Exercici 7

Escriu un programa que demani un número i escrigui els seus divisors.

Per exemple:

"Introdueix un número: 12"
"Divisors de 12: 1, 2, 3, 4, 6, 12"

Els divisors són els números que divideixen un número sense deixar residu.

"""