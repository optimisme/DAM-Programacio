"""
Exercici 1

Genera un programa que simuli una partida entre l'Ana i en Bernat.

Cada un comença amb 9 punts i tiren un dau.

- Si surt 1, 3 o 5 l'Ana resta els punts que han sortit.

- Si surt 2, 4 o 6 en Bernat resta els punts que han sortit.

La partida s'acaba quan un d'ells es queda sense punts.

Aleatòriament, la sortida ha de ser de l'estil:

- "Ana ha tret 3 punts i ara en té 6"

- "Bernat ha tret 6 punts i ara en té 3"

- "Bernat ha tret 2 punts i ara en té 1"

- "Ana ha tret 5 punts i ara en té 1"

- "Ana ha tret 3 punts i ara en té 0"

- "En Bernat ha guanyat la partida"

"""