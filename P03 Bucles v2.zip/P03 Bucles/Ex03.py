"""
Exercici 3

Fes un programa que calcula el número de la sort d'una persona.

Primer demana la data de naixement en format dd/mm/aaaa.

Si el format no és correcte, mostra el missatge "Format incorrecte" i torna a demanar la data.

El número de la rot es calcula sumant tots els números de la data de naixement, 
sumant tots els números d'aquest resultat i així fins que s'obté un número d'un sol dígit.

Per exemple:

29091981
2 + 9 + 0 + 9 + 1 + 9 + 8 + 1 = 39
3 + 9 = 12
1 + 2 = 3

"""