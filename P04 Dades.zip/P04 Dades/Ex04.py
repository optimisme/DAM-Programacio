"""
Sense fer servir 'sorted' ni 'sort', 
fes un programa que ordeni una llista de 5 paraules.

Passa primer les paraules a minúscules.
"""