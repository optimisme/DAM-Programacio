"""
Fes un programa, que a partir de la següent llista:

- Busqui la posició de l'element 7.2 i la canvii per 4.5
- Mostri la llista actualitzada
- Mostri la llista inversa
- Mostri la llista ordenada de forma ascendent.
- Mostri la llista ordenada de forma descendent.
- Mostri els valors a les posicions parells (0, 2, 4, ...)

Evidenement, totes les accions s'han de fer programàticament. 

És a dir no pots fer llista[3] = 4.5, 
sinó que has de buscar la posició de l'element 7.2
"""
llista = [2.3, 5.6, 7.2, 5.0, 3.1, 2.2]