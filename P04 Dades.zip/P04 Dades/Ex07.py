"""
Fes un programa que a partir d'una llista de noms, escrigui:

Estimat XXX m'alegro de veure't

Ho ha de fer partir dels noms que es troben 
entre dues posicions introduides per l'usuari.
"""
noms = ["Toni", "Sara", "Joan", "Maria", "Pere", "Anna", "Jordi", "Laura", "Marc"]