"""
Fes un programa que a partir d'una cadena de text, 
busqui els caràcters numèrics que conté i els sumi.

Per exemple:

text = "En Toni té 2 gats i 3 gossos" > 5
text = "Hola 123" > 6
text = "La Sara ha comprat 25 pomes i 18 taronges" > 16
"""