"""
Fes un programa que calculi el número de lletres majúscules en una cadena de text.
"""