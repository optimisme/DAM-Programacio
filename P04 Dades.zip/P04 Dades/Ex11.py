"""
Fes una funció (treu_repetides) que donada una llista de paraules,
retorni una llista amb les paraules anteriors però sense repetir.

Fes-ho servir per mostrar totes les paraules diferents que hi ha en aquest text.

Mostra el següent text en una llista sense paraules repetides.
"""
text = "Never, never and never again shall it be that this beautiful land will again experience the oppression of one by another"