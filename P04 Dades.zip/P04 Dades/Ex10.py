"""
Fes un programa que donada una llista de números enters,
retorni un diccionari tipus.

{
    parells: [llista amb els números parells],
    senars: [llista amb els números senars]
}

"""