"""
Fes un programa demani un número de DNI,
i després calculi la lletra a partir del número.

Per fer-ho cal dividir el número del DNI per 23
i obtenir el residu d'aquesta divisió (mòdul, %).

Aquest mòdul correspòn a la lletra segons:

lletres_dni = "TRWAGMYFPDXBNJZSQVHLCKE"

És a dir, si el mòdul és 0 la lletra és T, 
si el mòdul és 1 la lletra és R, etc.
"""
