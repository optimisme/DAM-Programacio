"""
Fes un programa que a partir d'un text,
retorni un diccionari amb:

{
    "inici_vocal": [llista de paraules que començen en vocal],
    "inici_i_final_vocal": [llista de paraules que començen en consonant i acaben en vocal],
    "inici_o_final_vocal": [llista de paraules que començen en vocal o acaben en vocal]
}

Les llistes anteriors no poden tenir paraules repetides

"""
frase = "We choose to go to the moon in this decade and do the other things, not because they are easy, but because they are hard, because that goal will serve to organize and measure the best of our energies and skills, because that challenge is one that we are willing to accept, one we are unwilling to postpone, and one which we intend to win, and the others, too."
