"""
Fes un programa, que donat una llista de números enters, 
demani a l'usuari un d'aquests números i generi dues llistes:

* Una llista amb els números menors que el número introduït
* Una llista amb els números majors que el número introduït

Aleshores ha de genear un diccionari tipus:

{
    "menors": [llista amb els números menors],
    "numero": valor_introduit,
    "majors": [llista amb els números majors]
}

"""
llista = [4,15,6,12,18,32,25,47,12,28,39,50]