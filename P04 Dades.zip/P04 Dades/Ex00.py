"""
Escriure un programa que sol·liciti a l’usuari que introdueixi noms:

1. Si el nom es troba en l’agenda (implementada amb un diccionari),
mostrarà el telèfon i, opcionalment, ha de permetre modificar-ho.

2. Si el nom no es troba, ha de permetre afegir el contacte a l’agenda
inserint el telèfon i el nom corresponent.

L’usuari utilitzarà la cadena ‘sortir’ per sortir de la aplicació.

"""