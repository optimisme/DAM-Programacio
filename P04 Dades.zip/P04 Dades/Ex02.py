"""
Fes un programa que a partir d'una cadena de text, 
separi els valors numèrics i els sumi.

Per exemple:

text = "En Toni té 2 gats i 3 gossos" > 5
text = "Hola 123" > 123
text = "La Sara ha comprat 25 pomes i 18 taronges" > 43
"""