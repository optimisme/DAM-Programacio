"""
Fes un programa que a partir de dues frases, 
retorni un diccionari tipus:

{
    "repetides": [llista amb paraules que apareixen als dos textos],
    "diferents": [llista amb paraules que apareixen només en un dels textos],
    "primera": [llista amb paraules que apareixen només en el primer text],
    "segona": [llista amb paraules que apareixen només en el segon text]
}

Les llistes anteriors no poden tenir paraules repetides

"""
frase1 = "Your time is limited, so don't waste it living someone else's life. Don't be trapped by dogma — which is living with the results of other people's thinking. Don't let the noise of others' opinions drown out your own inner voice. And most important, have the courage to follow your heart and intuition ... Stay hungry, Stay foolish"
frase2 = "We choose to go to the moon in this decade and do the other things, not because they are easy, but because they are hard, because that goal will serve to organize and measure the best of our energies and skills, because that challenge is one that we are willing to accept, one we are unwilling to postpone, and one which we intend to win, and the others, too."