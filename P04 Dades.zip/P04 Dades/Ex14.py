"""
Fes un programa que a partir de la següent 
llista d'alçades d'alumnes, afegeixi al diccionari
l'etiqueta 'creixement' amb el valor de la diferència
que han crescut durant el curs.

Després ha de printar cada un dels alumnes en una línia
"""
alumnes = [
    {"nom": "Joan", "alt_setembre": 160, "alt_juny": 168},
    {"nom": "Maria", "alt_setembre": 155, "alt_juny": 162},
    {"nom": "Carles", "alt_setembre": 170, "alt_juny": 175},
    {"nom": "Anna", "alt_setembre": 158, "alt_juny": 165},
    {"nom": "Pere", "alt_setembre": 175, "alt_juny": 180},
    {"nom": "Laura", "alt_setembre": 162, "alt_juny": 169},
    {"nom": "Lluís", "alt_setembre": 168, "alt_juny": 175},
    {"nom": "Elena", "alt_setembre": 152, "alt_juny": 157},
    {"nom": "Diego", "alt_setembre": 180, "alt_juny": 185},
    {"nom": "Sofia", "alt_setembre": 170, "alt_juny": 178}
]
